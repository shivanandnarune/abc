import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ManagerComponent } from './manager.component';
import { Routes, RouterModule } from '@angular/router';

const managerRouting : Routes = [
  {
    path: '',
    component: ManagerComponent
  }
]
@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(managerRouting)
  ],
  declarations: [ManagerComponent]
})
export class ManagerModule { }
