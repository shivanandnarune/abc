import { NgModule, Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminComponent } from './admin.component';
import { RouterModule, Routes } from '@angular/router';

const adminRouting: Routes = [
  {
  path: '',
  component: AdminComponent
  }
]
@NgModule({  
  imports: [
    CommonModule,
    RouterModule.forChild(adminRouting)
  ],
  declarations: [AdminComponent]
})
export class AdminModule { }
