import { Component, OnInit } from '@angular/core';
import { UserService } from './userService/user.service';
import { User } from '../../model/user.model';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  constructor(
    private userService : UserService 
  ) { }

  ngOnInit() {
    this.getallUser();
    
  }
  allUsers: User[];
  getallUser(){
    this.userService.getAllUsers().subscribe(
      (data)=> {this.allUsers=data;},
      (error)=> {console.log(error);},
      ()=> {console.log("All Users Recieved");}
    );
  }
  deleteUser(id: number){
    alert("In Delete")
    this.userService.deleteUsers(id).subscribe(
      (data)=> {this.getallUser();},
      
    );
  }

  editUser(){
    alert("In Edit")
    
  }
}
