import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserComponent } from './user.component';
import { Routes, RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http'
import { UserService } from './userService/user.service';



const userRouting: Routes = [
  {
    path: '',
    component: UserComponent
  }
]
@NgModule({
  imports: [
    CommonModule,
    HttpClientModule,
    RouterModule.forChild(userRouting)
  ],
  providers: [UserService],
  declarations: [UserComponent],
  //exports: [UserComponent]
})
export class UserModule { }
