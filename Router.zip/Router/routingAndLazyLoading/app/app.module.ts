import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {RouterModule,Routes} from '@angular/router'
import { AppComponent } from './app.component';
import { RoleComponent } from './routes/shaired/role/role.component';

const AppRouting: Routes = [
{

  path: 'role',
  component: RoleComponent,
  children:[
      {
        path: 'admin',
        loadChildren: './routes/admin/admin.module#AdminModule'
      },
      {
        path: 'manager',
        loadChildren: './routes/manager/manager.module#ManagerModule'
      },
      { 
        path: 'user',
        loadChildren: './routes/user/user.module#UserModule'
      }
  ]
}

];


@NgModule({
  declarations: [
    AppComponent,
    RoleComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(AppRouting)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
