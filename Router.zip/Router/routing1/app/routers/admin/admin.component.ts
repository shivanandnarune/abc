import { Component, OnInit } from '@angular/core';
import { AdminService } from './shaired/admin.service';
import { Admin } from '../../model/admin.model';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  constructor(
    private adminService: AdminService
  ) { }

  ngOnInit() {
    this.getAllAdmin();
  }
allAdmin:Admin[];

  getAllAdmin(){
    this.adminService.getAdmins().subscribe(
      (data) => {this.allAdmin=data;},
      (error) => {console.log(error);},
      () => {console.log("Recieved All employee");}
    );
  }

}
