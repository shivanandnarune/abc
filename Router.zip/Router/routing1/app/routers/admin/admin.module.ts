import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminComponent } from './admin.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { AdminService } from './shaired/admin.service';

@NgModule({
  imports: [
    CommonModule,
    HttpClientModule
  ],
  declarations: [AdminComponent],
  exports: [AdminComponent],
  providers: [AdminService]
})
export class AdminModule { }
