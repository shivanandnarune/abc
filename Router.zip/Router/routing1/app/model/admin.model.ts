export class Admin {
    id: number;
    name: string;
    address: string;
}