import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';

import { EmployeeModule } from './routers/employee/employee.module';
import { AdminModule } from './routers/admin/admin.module';
import { AdminComponent } from './routers/admin/admin.component';
import { ManagerModule } from './routers/manager/manager.module';
import { UserModule } from './routers/user/user.module';

const appRouting: Routes = [
  {path: 'admin', component: AdminComponent}
]

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(appRouting),
    EmployeeModule,
    AdminModule,
    ManagerModule,
    UserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
